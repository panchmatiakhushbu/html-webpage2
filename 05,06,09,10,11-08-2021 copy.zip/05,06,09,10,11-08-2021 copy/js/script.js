/*bootstrap datepicker js start*/
$('#inputDate').datepicker({});
/*bootstrap datepicker js end*/


/*progress js start*/
let slider = document.getElementById('slider');
let background = document.querySelector('.calculate-top');
let procentBlock = document.getElementById('income');
let calculateBtn = document.querySelector('.calculate-btn');
let value = document.getElementById("text");
let prop = document.getElementById('prop');
let inputs = [value];
noUiSlider.create(slider, {
    start: [500],
    connect: [true, false],
    range: {
        'min': 50000,
        'max': 500000
    },
    step: 5000,
    format: {
        from: function(value) {
            return Math.round(+value);
        },
        to: function(value) {
            return Math.round(+value);
        }
    },
});

/*progress js end*/

/*chart js start*/
/*1 chart js start*/
var ctx = document.getElementById("myChart").getContext('2d');

var myChart = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Mon", "Tues", "Wed", "Thu", "Fri"],
        datasets: [{
            data: [55, 65, 57, 72],
            fill: false,
            borderColor: '#6094FF',
            backgroundColor: '#6094FF',
            borderWidth: 2
        }]
    },
    options: {
        maintainAspectRatio: false,
        responsive: true,
        elements: {
            point: {
                radius: 3,
            }
        },
        legend: {
            display: false
        },
        scales: {
            xAxes: [{
                ticks: {
                    fontColor: "#93B0C8",
                    fontSize: 14,
                },
                gridLines: {
                    display: false
                }
            }],
            yAxes: [{
                display: true,
                position: 'right',
                ticks: {
                    stepSize: 10,
                    fontColor: "#93B0C8",
                    fontSize: 14,
                },
            }],
        }
    }
});

/*1 chart js end*/
/*2 chart js start*/

var ctx = document.getElementById("myChart1").getContext('2d');

var myChart1 = new Chart(ctx, {
    type: 'line',
    data: {
        labels: ["Mon", "Tues", "Wed", "Thu", "Fri"],
        datasets: [{
            data: [130, 140, 125, 160],
            fill: false,
            borderColor: '#6094FF',
            backgroundColor: '#6094FF',
            borderWidth: 2
        }]
    },
    options: {
        maintainAspectRatio: false,
        responsive: true,
        elements: {
            point: {
                radius: 3,
            }
        },
        legend: {
            display: false
        },
        scales: {
            xAxes: [{
                ticks: {
                    fontColor: "#93B0C8",
                    fontSize: 14,
                },
                gridLines: {
                    display: false
                }
            }],
            yAxes: [{
                display: true,
                position: 'right',
                ticks: {
                    stepSize: 10,
                    fontColor: "#93B0C8",
                    fontSize: 14,
                },
            }],
        }
    }
});

/*2 chart js end*/

/*chart js end*/

/*Date picker js start*/

$(function() {
    $('#my_calendar_calSize').rescalendar({
        id: 'my_calendar_calSize',
        jumpSize: 1,
        calSize: 6,
        dataKeyField: 'name',
        dataKeyValues: ['item1', 'item2', 'item3', 'item4', 'item5']
    });
});

/*Date picker js end*/

/*progress circle js start*/
$(function() {
  $('.chart').easyPieChart({
    size: 20,
    barColor: "#3B76EF",
    scaleLength: 0,
    lineWidth: 4,
    trackColor: "#DBEBF8",
    lineCap: "circle",
    animate: 2000,
  });
});


$(function() {
  $('.chart1').easyPieChart({
    size: 175,
    barColor: "#FFFFFF",
    scaleLength: 0,
    lineWidth: 4,
    trackColor: "#ffffff4d",
    lineCap: "circle",
    animate: 2000,
  });
});
/*progress circle js end*/

/*Splits progress js start*/
$(".meter > span").each(function() {
    $(this)
        .data("origWidth", $(this).width())
        .width(0)
        .animate({
            width: $(this).data("origWidth")
        }, 1200);
});

/*Splits progress js end*/